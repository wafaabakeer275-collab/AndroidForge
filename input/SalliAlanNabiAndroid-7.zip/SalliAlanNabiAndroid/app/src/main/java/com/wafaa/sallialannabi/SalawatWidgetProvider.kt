package com.wafaa.sallialannabi

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class SalawatWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_INCREMENT -> CounterStore.increment(context)
            ACTION_RESET -> CounterStore.resetDaily(context)
        }
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, SalawatWidgetProvider::class.java))
        updateAll(context, manager, ids)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context, manager, ids)
    }

    companion object {
        const val ACTION_INCREMENT = "com.wafaa.sallialannabi.INCREMENT"
        const val ACTION_RESET = "com.wafaa.sallialannabi.RESET"

        fun updateAll(context: Context, manager: AppWidgetManager, ids: IntArray) {
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.salawat_widget)
                val daily = CounterStore.daily(context)
                val target = CounterStore.target(context)
                views.setTextViewText(R.id.widget_count, "$daily / $target")
                views.setTextViewText(
                    R.id.widget_message,
                    if (daily >= target) "أتممتِ وردك اليوم ♥" else "صلّي على النبي ﷺ"
                )

                val incrementIntent = Intent(context, SalawatWidgetProvider::class.java).apply {
                    action = ACTION_INCREMENT
                }
                val incrementPending = PendingIntent.getBroadcast(
                    context, 100 + id, incrementIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_increment, incrementPending)

                val openIntent = Intent(context, MainActivity::class.java)
                val openPending = PendingIntent.getActivity(
                    context, 200 + id, openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_open, openPending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
