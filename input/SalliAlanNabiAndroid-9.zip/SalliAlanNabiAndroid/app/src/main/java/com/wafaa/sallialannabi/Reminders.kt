package com.wafaa.sallialannabi

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Reminders {
    const val ACTION_REMIND = "com.wafaa.sallialannabi.REMIND"

    private const val CHANNEL_ID = "salawat_reminders"
    private const val PREFS = "salawat_reminders"
    private const val KEY_NEXT = "next_message"
    private const val REQUEST_ALARM = 1
    private const val REQUEST_OPEN = 300
    private const val NOTIFICATION_ID = 1001

    // كل قد إيه يوصل إشعار (حاليًا كل نص ساعة)
    private const val INTERVAL_MS = 30 * 60 * 1000L

    // الإشعارات بتتبدّل بين الجملتين دول
    private val MESSAGES = listOf(
        "صل على النبي لتكفى همك",
        "صل على النبي ليغفر ذنبك"
    )

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "تذكير الصلاة على النبي",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        manager.createNotificationChannel(channel)
    }

    private fun alarmIntent(context: Context): Intent =
        Intent(context, ReminderReceiver::class.java).apply { action = ACTION_REMIND }

    // بيبدأ التذكير بس لو مش شغّال، علشان فتح التطبيق ما يأخّرش الإشعار القادم
    fun scheduleIfNeeded(context: Context) {
        val existing = PendingIntent.getBroadcast(
            context, REQUEST_ALARM, alarmIntent(context),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (existing == null) schedule(context)
    }

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_ALARM, alarmIntent(context),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + INTERVAL_MS,
            INTERVAL_MS,
            pending
        )
    }

    @Suppress("DEPRECATION")
    fun show(context: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        ensureChannel(context)

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val index = prefs.getInt(KEY_NEXT, 0) % MESSAGES.size
        prefs.edit().putInt(KEY_NEXT, (index + 1) % MESSAGES.size).apply()

        val openPending = PendingIntent.getActivity(
            context, REQUEST_OPEN, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            Notification.Builder(context)
        }
        val notification = builder
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(MESSAGES[index])
            .setContentIntent(openPending)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }
}
