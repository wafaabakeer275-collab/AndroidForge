package com.wafaa.sallialannabi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            // بعد إعادة تشغيل الموبايل بنرجّع التذكير تاني
            Intent.ACTION_BOOT_COMPLETED -> Reminders.schedule(context)
            Reminders.ACTION_REMIND -> Reminders.show(context)
        }
    }
}
