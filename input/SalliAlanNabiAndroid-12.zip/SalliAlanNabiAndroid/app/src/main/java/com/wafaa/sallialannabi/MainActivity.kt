package com.wafaa.sallialannabi

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val green = Color.rgb(28, 61, 45)
    private val gold = Color.rgb(202, 166, 91)
    private val cream = Color.rgb(248, 245, 235)
    private lateinit var countText: TextView
    private lateinit var targetText: TextView
    private lateinit var progressText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refresh()
        setupReminders()
    }

    // يجهّز قناة الإشعارات، ويبدأ التذكير الدوري، ويطلب إذن الإشعارات (أندرويد 13 وما بعده)
    private fun setupReminders() {
        Reminders.ensureChannel(this)
        Reminders.scheduleIfNeeded(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(green)
        }

        val title = TextView(this).apply {
            text = "على النبي وآل البيت والشهدا\nمولاي صلّ وسلم دائمًا أبدا"
            textSize = 24f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "اللهم صلِّ وسلم على نبينا محمد"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        countText = TextView(this).apply {
            textSize = 54f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        targetText = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 4)
        }
        progressText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 22)
        }

        val countButton = Button(this).apply {
            text = "صلى الله عليه وسلم"
            textSize = 18f
            setTextColor(green)
            setBackgroundColor(gold)
            setOnClickListener {
                CounterStore.increment(this@MainActivity)
                refresh()
            }
        }
        val targetButton = Button(this).apply {
            text = "تغيير الورد اليومي"
            setOnClickListener {
                val choices = arrayOf("33 مرة", "100 مرة", "300 مرة", "500 مرة", "1000 مرة")
                val values = intArrayOf(33, 100, 300, 500, 1000)
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("اختر وردك اليومي")
                    .setItems(choices) { _, which ->
                        CounterStore.setTarget(this@MainActivity, values[which])
                        refresh()
                    }.show()
            }
        }
        val resetButton = Button(this).apply {
            text = "تصفير عدّاد اليوم"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setMessage("تصفير عدد اليوم؟ سيبقى الإجمالي محفوظًا.")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("تصفير") { _, _ ->
                        CounterStore.resetDaily(this@MainActivity)
                        refresh()
                    }.show()
            }
        }
        val note = TextView(this).apply {
            text = "كلما تذكّرنا، صلّينا على النبي ﷺ"
            textSize = 15f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }

        listOf(title, subtitle, countText, targetText, progressText, countButton, targetButton, resetButton, note)
            .forEach { view ->
                root.addView(view, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 8 })
            }
        setContentView(root)
    }

    private fun refresh() {
        val daily = CounterStore.daily(this)
        val target = CounterStore.target(this)
        countText.text = daily.toString()
        targetText.text = "من $target صلاة اليوم"
        progressText.text = if (daily >= target) "ما شاء الله، تم وردك اليومي ♥" else "باقي ${target - daily} لإتمام الورد • الإجمالي ${CounterStore.total(this)}"
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, SalawatWidgetProvider::class.java))
        if (ids.isNotEmpty()) SalawatWidgetProvider.updateAll(this, manager, ids)
    }
}
