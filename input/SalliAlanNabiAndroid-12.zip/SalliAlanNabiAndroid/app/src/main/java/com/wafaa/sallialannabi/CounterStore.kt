package com.wafaa.sallialannabi

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CounterStore {
    private const val PREFS = "salawat_prefs"
    private const val DAILY_COUNT = "daily_count"
    private const val TOTAL_COUNT = "total_count"
    private const val SAVED_DATE = "saved_date"
    private const val TARGET = "target"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized
    fun syncDay(context: Context) {
        val p = prefs(context)
        if (p.getString(SAVED_DATE, "") != today()) {
            p.edit().putString(SAVED_DATE, today()).putInt(DAILY_COUNT, 0).apply()
        }
    }

    fun daily(context: Context): Int {
        syncDay(context)
        return prefs(context).getInt(DAILY_COUNT, 0)
    }

    fun total(context: Context): Int = prefs(context).getInt(TOTAL_COUNT, 0)
    fun target(context: Context): Int = prefs(context).getInt(TARGET, 100)

    fun setTarget(context: Context, target: Int) {
        prefs(context).edit().putInt(TARGET, target.coerceAtLeast(1)).apply()
    }

    fun increment(context: Context) {
        syncDay(context)
        val p = prefs(context)
        p.edit()
            .putInt(DAILY_COUNT, p.getInt(DAILY_COUNT, 0) + 1)
            .putInt(TOTAL_COUNT, p.getInt(TOTAL_COUNT, 0) + 1)
            .apply()
    }

    fun resetDaily(context: Context) {
        syncDay(context)
        prefs(context).edit().putInt(DAILY_COUNT, 0).apply()
    }
}
