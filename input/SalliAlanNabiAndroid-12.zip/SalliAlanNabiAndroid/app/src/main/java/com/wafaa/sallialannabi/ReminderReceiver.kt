package com.wafaa.sallialannabi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            // بعد إعادة تشغيل الموبايل أو تحديث التطبيق بنرجّع التذكير تاني
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> Reminders.schedule(context)

            // بنجدول الإشعار اللي بعده الأول، وبعدين نعرض الحالي
            Reminders.ACTION_REMIND -> {
                Reminders.schedule(context)
                Reminders.show(context)
            }
        }
    }
}
