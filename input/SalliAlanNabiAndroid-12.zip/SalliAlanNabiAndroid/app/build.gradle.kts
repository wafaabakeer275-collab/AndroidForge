import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wafaa.sallialannabi"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.wafaa.sallialannabi"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // مفتاح توقيع ثابت: كل نسخة جديدة تتثبّت فوق القديمة من غير ما تتمسح.
    // ملاحظة: لا تغيّروا الملف signing.keystore، لأن تغييره يرجّع مشكلة "App not installed".
    signingConfigs {
        getByName("debug") {
            storeFile = file("signing.keystore")
            storePassword = "sallialannabi"
            keyAlias = "sallikey"
            keyPassword = "sallialannabi"
        }
    }

    // Java و Kotlin لازم يكونوا على نفس الـ JVM target (17)،
    // وإلا Gradle بيرفض البناء: "Inconsistent JVM-target compatibility".
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}
